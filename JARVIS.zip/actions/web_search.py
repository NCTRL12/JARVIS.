#web_search.py
import json
import sys
from pathlib import Path

def _get_base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent


BASE_DIR        = _get_base_dir()
API_CONFIG_PATH = BASE_DIR / "config" / "api_keys.json"

_GEMINI_SEARCH_MODEL = "gemini-2.0-flash"


def _get_api_key() -> str:
    with open(API_CONFIG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)["gemini_api_key"]


def _gemini_search(query: str) -> str:
    from google import genai

    client   = genai.Client(api_key=_get_api_key())
    response = client.models.generate_content(
        model=_GEMINI_SEARCH_MODEL,
        contents=query,
        config={"tools": [{"google_search": {}}]},
    )

    text = ""
    for part in response.candidates[0].content.parts:
        if hasattr(part, "text") and part.text:
            text += part.text

    text = text.strip()
    if not text:
        raise ValueError("Gemini returned an empty response.")
    return text


def _ddg_search(query: str, max_results: int = 6) -> list[dict]:
    try:
        from ddgs import DDGS
    except ImportError:
        from duckduckgo_search import DDGS

    results = []
    with DDGS() as ddgs:
        for r in ddgs.text(query, max_results=max_results):
            results.append({
                "title":   r.get("title",  ""),
                "snippet": r.get("body",   ""),
                "url":     r.get("href",   ""),
            })
    return results


def _ddg_news(query: str, max_results: int = 8) -> list[dict]:
    """DDG news search -- returns actual articles, not website homepages."""
    try:
        from ddgs import DDGS
    except ImportError:
        from duckduckgo_search import DDGS

    results = []
    try:
        with DDGS() as ddgs:
            for r in ddgs.news(query, max_results=max_results):
                results.append({
                    "title":   r.get("title",  ""),
                    "snippet": r.get("body",   ""),
                    "url":     r.get("url",    ""),
                    "source":  r.get("source", ""),
                })
    except Exception as e:
        print(f"[WebSearch] DDG news() failed ({e}) -- falling back to text search")
        results = _ddg_search(query, max_results=max_results)
    return results


def _rss_news(query: str = "", max_results: int = 10) -> list[dict]:
    """
    RSS feed news -- zero API keys, zero rate limits.
    If query is provided, searches Google News RSS for that topic.
    Otherwise returns general top headlines from multiple feeds.
    """
    import xml.etree.ElementTree as ET
    import urllib.request
    import urllib.parse
    import ssl

    import re as _re
    import html as _html

    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE

    # Build feed list: search-specific if query provided, otherwise top headlines
    if query:
        q = urllib.parse.quote_plus(query)
        feeds = [
            f"https://news.google.com/rss/search?q={q}&hl=en-US&gl=US&ceid=US:en",
        ]
    else:
        feeds = [
            "https://news.google.com/rss?hl=en-US&gl=US&ceid=US:en",
            "https://feeds.bbci.co.uk/news/world/rss.xml",
            "https://rss.nytimes.com/services/xml/rss/nyt/World.xml",
        ]

    results = []
    seen_titles = set()

    def _strip_html(s: str) -> str:
        return _html.unescape(_re.sub(r'<[^>]+>', '', s)).strip()

    for url in feeds:
        try:
            req = urllib.request.Request(url, headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
            })
            with urllib.request.urlopen(req, timeout=6, context=ctx) as resp:
                data = resp.read().decode("utf-8", errors="replace")

            root = ET.fromstring(data)
            for item in root.iter("item"):
                title_el = item.find("title")
                link_el  = item.find("link")
                desc_el  = item.find("description")
                src_el   = item.find("source")

                title = _strip_html(title_el.text or "") if title_el is not None else ""
                link  = (link_el.text or "").strip()     if link_el  is not None else ""
                desc  = _strip_html(desc_el.text or "")  if desc_el  is not None else ""
                src   = (src_el.text or "").strip()       if src_el   is not None else ""

                if not title or title.lower() in seen_titles:
                    continue
                seen_titles.add(title.lower())

                results.append({
                    "title":   title,
                    "snippet": desc[:200],
                    "url":     link,
                    "source":  src or "RSS",
                })

                if len(results) >= max_results:
                    return results
        except Exception as e:
            print(f"[WebSearch] RSS feed failed ({url[:40]}...): {e}")
            continue

    return results


def _format_ddg(query: str, results: list[dict]) -> str:
    if not results:
        return f"No results found for: {query}"

    lines = [f"Search results for: {query}\n"]
    for i, r in enumerate(results, 1):
        if r.get("title"):   lines.append(f"{i}. {r['title']}")
        if r.get("snippet"): lines.append(f"   {r['snippet']}")
        if r.get("url"):     lines.append(f"   Source: {r['url']}")
        lines.append("")
    return "\n".join(lines).strip()


def _format_news(query: str, results: list[dict]) -> str:
    if not results:
        return f"No news found for: {query}"

    lines = [f"Latest news: {query}\n"]
    for i, r in enumerate(results, 1):
        title = r.get("title", "")
        if not title:
            continue
        src = f"  [{r['source']}]" if r.get("source") else ""
        lines.append(f"{i}. {title}{src}")
        if r.get("snippet"):
            lines.append(f"   {r['snippet'][:140]}")
        if r.get("url"):
            lines.append(f"   {r['url']}")
        lines.append("")
    return "\n".join(lines).strip()


# -- Briefing helper -----------------------------------------------------------

def _gemini_headlines(n: int = 5) -> tuple[list[str], str]:
    """
    Fetches current headlines via Gemini grounded search.
    Falls back to RSS if Gemini fails.
    Returns (headline_list, raw_text_for_display).
    """
    import re

    try:
        from google import genai

        client = genai.Client(api_key=_get_api_key())
        response = client.models.generate_content(
            model=_GEMINI_SEARCH_MODEL,
            contents=f"Current world news: {n} headlines. Numbered list, titles only.",
            config={"tools": [{"google_search": {}}]},
        )

        raw = ""
        for part in response.candidates[0].content.parts:
            if hasattr(part, "text") and part.text:
                raw += part.text

        headlines = []
        for line in raw.strip().split("\n"):
            line = line.strip()
            if not line:
                continue
            if not re.match(r'^[\d]+[.\)\-]', line):
                continue
            clean = re.sub(r'^[\d]+[.\)\-]\s*', '', line)
            clean = re.sub(r'^\*+\s*',          '', clean).strip()
            if clean and len(clean) > 10:
                headlines.append(clean)

        if headlines:
            return headlines[:n], raw.strip()
    except Exception as e:
        print(f"[WebSearch] Gemini headlines failed ({e}) -- using RSS")

    # Fallback: RSS feeds
    rss = _rss_news(max_results=n)
    if rss:
        headlines = [r["title"] for r in rss[:n] if r.get("title")]
        raw = "\n".join(f"{i+1}. {h}" for i, h in enumerate(headlines))
        return headlines, raw

    return [], ""


# -- Modes ---------------------------------------------------------------------

def _search(query: str) -> str:
    """Default search -- Gemini grounded, DDG fallback, RSS fallback for current events."""
    try:
        return _gemini_search(query)
    except Exception as e:
        print(f"[WebSearch] Gemini failed ({e}) -- trying DDG...")
        try:
            results = _ddg_search(query)
            formatted = _format_ddg(query, results)
            if formatted and len(formatted) > 60:
                return formatted
        except Exception as e2:
            print(f"[WebSearch] DDG also failed ({e2}) -- trying RSS...")

        # RSS fallback -- useful for current events queries
        try:
            rss = _rss_news(query=query, max_results=8)
            if rss:
                return _format_news(query, rss)
        except Exception:
            pass
        return f"Search failed: {e}"


def _news(query: str) -> str:
    """
    Three-source parallel news: Gemini grounded, DDG news, RSS feeds.
    Returns whichever delivers a valid result first.
    """
    import threading

    gemini_query = f"latest news today: {query}" if query else "top world news today"
    ddg_query    = query if query else "world news today"

    result_box  = [None]
    lock        = threading.Lock()
    done_evt    = threading.Event()
    failures    = [0]
    total       = [3]  # Gemini, DDG, RSS

    def _store(r: str) -> None:
        if r and len(r) > 60:
            with lock:
                if result_box[0] is None:
                    result_box[0] = r
            done_evt.set()
        else:
            with lock:
                failures[0] += 1
                if failures[0] >= total[0]:
                    done_evt.set()

    def _try_gemini():
        try:
            _store(_gemini_search(gemini_query))
        except Exception as e:
            print(f"[WebSearch] Gemini news failed: {e}")
            _store("")

    def _try_ddg():
        try:
            results = _ddg_news(ddg_query, max_results=8)
            _store(_format_news(ddg_query, results))
        except Exception as e:
            print(f"[WebSearch] DDG news failed: {e}")
            _store("")

    def _try_rss():
        try:
            results = _rss_news(query=query, max_results=10)
            _store(_format_news(query or "world news", results))
        except Exception as e:
            print(f"[WebSearch] RSS news failed: {e}")
            _store("")

    threading.Thread(target=_try_gemini, daemon=True).start()
    threading.Thread(target=_try_ddg,    daemon=True).start()
    threading.Thread(target=_try_rss,    daemon=True).start()

    done_evt.wait(timeout=12.0)
    return result_box[0] or f"No news found for: {query}"


def _research(query: str) -> str:
    """
    Deep dive -- asks Gemini for a comprehensive answer with context.
    Falls back to DDG, then RSS.
    """
    research_query = (
        f"Comprehensive, detailed explanation of: {query}. "
        "Include background context, key facts, current state, and important nuances."
    )
    try:
        return _gemini_search(research_query)
    except Exception as e:
        print(f"[WebSearch] Research Gemini failed ({e}) -- DDG fallback...")
        try:
            results = _ddg_search(query, max_results=10)
            return _format_ddg(query, results)
        except Exception as e2:
            print(f"[WebSearch] DDG also failed ({e2}) -- RSS fallback...")
            try:
                results = _rss_news(query=query, max_results=10)
                return _format_news(query, results)
            except Exception:
                return f"Research failed: {e}"


def _price(query: str) -> str:
    """Product price lookup -- searches for current market prices."""
    price_query = f"current price of {query} -- how much does it cost today"
    try:
        return _gemini_search(price_query)
    except Exception as e:
        print(f"[WebSearch] Price Gemini failed ({e}) -- DDG fallback...")
        try:
            results = _ddg_search(f"{query} price buy", max_results=6)
            return _format_ddg(query, results)
        except Exception:
            return f"Price search failed for: {query}"


def _compare(items: list[str], aspect: str) -> str:
    query = (
        f"Compare {', '.join(items)} in terms of {aspect}. "
        "Give specific facts and data."
    )
    try:
        return _gemini_search(query)
    except Exception as e:
        print(f"[WebSearch] Gemini compare failed: {e} -- falling back to DDG")

    all_results: dict[str, list] = {}
    for item in items:
        try:
            all_results[item] = _ddg_search(f"{item} {aspect}", max_results=3)
        except Exception:
            all_results[item] = []

    lines = [f"Comparison -- {aspect.upper()}", "-" * 40]
    for item in items:
        lines.append(f"\n> {item}")
        for r in all_results.get(item, [])[:2]:
            if r.get("snippet"):
                lines.append(f"  * {r['snippet']}")
            if r.get("url"):
                lines.append(f"    {r['url']}")
    return "\n".join(lines)


# -- Public entry point --------------------------------------------------------

def web_search(
    parameters:     dict,
    response=None,
    player=None,
    session_memory=None,
) -> str:
    params = parameters or {}
    query  = params.get("query", "").strip()
    mode   = params.get("mode",  "search").lower().strip()
    items  = params.get("items", [])
    aspect = params.get("aspect", "general").strip() or "general"

    if not query and not items:
        return "Please provide a search query."

    if items and mode not in ("compare",):
        mode = "compare"

    if player:
        player.write_log(f"[Search:{mode}] {query or ', '.join(items)}")

    print(f"[WebSearch] mode={mode!r}  query={query!r}")

    try:
        if mode == "compare" and items:
            return _compare(items, aspect)
        if mode == "news":
            return _news(query)
        if mode == "research":
            return _research(query)
        if mode == "price":
            return _price(query)
        return _search(query)

    except Exception as e:
        print(f"[WebSearch] All backends failed: {e}")
        return f"Search failed: {e}"
