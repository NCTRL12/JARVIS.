"""
MARK XLIX - One-Click Installer
Run this file to install everything and create a desktop shortcut.
"""
import subprocess
import sys
import os
import platform
import shutil
from pathlib import Path

# -- Colors --------------------------------------------------------------------
IS_WIN = platform.system() == "Windows"

def _c(code, text):
    if IS_WIN:
        try:
            os.system("")
        except Exception:
            return text
    return f"\033[{code}m{text}\033[0m"

def ok(t):   return _c("92", t)
def warn(t): return _c("93", t)
def err(t):  return _c("91", t)
def hi(t):   return _c("96", t)
def bold(t): return _c("1", t)

# -- Helpers -------------------------------------------------------------------
BANNER = r"""
  __  __  ___  ____  __  __  ___  ____    _    _
 |  \/  |/ _ \|  _ \|  \/  |/ _ \|  _ \  / \  | |
 | |\/| | | | | |_) | |\/| | | | | | | |/ _ \ | |
 |_|  |_|___/|____/|_|  |_|___/|_| |_/_/ \_\|_|
         MARK XLIX  --  Installer
"""

BASE_DIR = Path(__file__).resolve().parent
PYTHON   = sys.executable
PY_DIR   = Path(PYTHON).parent

def _python_ok():
    v = sys.version_info
    if v < (3, 11):
        print(err(f"  Python 3.11+ required (found {v.major}.{v.minor})"))
        print(warn("  Download: https://www.python.org/downloads/"))
        return False
    print(ok(f"  Python {v.major}.{v.minor}.{v.micro} OK"))
    return True

def _pip_install():
    print(hi("  Installing Python dependencies..."))
    req = BASE_DIR / "requirements.txt"
    if not req.exists():
        print(err("  requirements.txt not found!"))
        return False
    r = subprocess.run(
        [PYTHON, "-m", "pip", "install", "-r", str(req), "--quiet"],
        capture_output=True, text=True,
    )
    if r.returncode != 0:
        print(err(f"  pip failed:\n{r.stderr[-500:]}"))
        return False
    print(ok("  Dependencies installed"))
    return True

def _playwright_install():
    print(hi("  Installing Playwright browsers..."))
    r = subprocess.run(
        [PYTHON, "-m", "playwright", "install"],
        capture_output=True, text=True, timeout=300,
    )
    if r.returncode != 0:
        print(warn(f"  Playwright warning (non-critical): {r.stderr[-200:]}"))
    else:
        print(ok("  Playwright browsers installed"))
    return True

def _pywin32_fix():
    if not IS_WIN:
        return True
    try:
        import win32com.client
        print(ok("  pywin32 OK"))
        return True
    except ImportError:
        print(warn("  Fixing pywin32..."))
        post = PY_DIR / "Scripts" / "pywin32_postinstall.py"
        if post.exists():
            subprocess.run([PYTHON, str(post), "-install"],
                           capture_output=True, timeout=30)
        try:
            import win32com.client
            print(ok("  pywin32 fixed"))
            return True
        except ImportError:
            print(warn("  pywin32 could not be fixed -- shortcut will use fallback"))
            return True

def _get_desktop():
    if IS_WIN:
        try:
            import ctypes
            from ctypes import wintypes
            class _GUID(ctypes.Structure):
                _fields_ = [("Data1", wintypes.DWORD), ("Data2", wintypes.WORD),
                            ("Data3", wintypes.WORD), ("Data4", ctypes.c_ubyte * 8)]
            fid = _GUID(0xB4BFCC3A, 0xDB2C, 0x424C,
                        (ctypes.c_ubyte * 8)(0xB0, 0x29, 0x7F, 0xE9, 0x9A, 0x87, 0xC6, 0x41))
            buf = ctypes.c_wchar_p()
            if ctypes.windll.shell32.SHGetKnownFolderPath(
                    ctypes.byref(fid), 0, None, ctypes.byref(buf)) == 0:
                p = Path(buf.value)
                ctypes.windll.ole32.CoTaskMemFree(buf)
                if p.is_dir():
                    return p
        except Exception:
            pass
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                r"Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders") as key:
                val, _ = winreg.QueryValueEx(key, "Desktop")
            p = Path(os.path.expandvars(val))
            if p.is_dir():
                return p
        except Exception:
            pass
    return Path.home() / "Desktop"

def _build_icon():
    ico = BASE_DIR / "config" / "jarvis.ico"
    if ico.exists():
        return ico
    try:
        import math, io
        from PIL import Image, ImageDraw, ImageFilter

        CYAN = (0, 212, 255); DIM = (0, 100, 140); DARK = (0, 6, 10)
        GLOW = (0, 160, 200); WHITE = (220, 240, 255)

        def _render(sz):
            S = sz * 4
            img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
            d = ImageDraw.Draw(img)
            cx = cy = S // 2
            R = S // 2 - 2
            d.ellipse([cx-R, cy-R, cx+R, cy+R], fill=(*DARK, 255))
            lw = max(2, S // 40)
            d.ellipse([cx-R, cy-R, cx+R, cy+R], outline=(*CYAN, 220), width=lw)
            R2 = int(R * 0.72)
            d.ellipse([cx-R2, cy-R2, cx+R2, cy+R2], outline=(*DIM, 180), width=max(1, lw // 2))
            R_inner = int(R * 0.30); R_outer = int(R * 0.62)
            for i in range(6):
                a = math.radians(i * 60 - 30)
                x1 = cx + int(R_inner * math.cos(a)); y1 = cy + int(R_inner * math.sin(a))
                x2 = cx + int(R_outer * math.cos(a)); y2 = cy + int(R_outer * math.sin(a))
                d.line([x1, y1, x2, y2], fill=(*GLOW, 200), width=max(1, S // 80))
            Ri = int(R * 0.26)
            d.ellipse([cx-Ri, cy-Ri, cx+Ri, cy+Ri], outline=(*CYAN, 255), width=max(2, lw))
            glow = Image.new("RGBA", (S, S), (0, 0, 0, 0))
            gd = ImageDraw.Draw(glow)
            Rc = int(R * 0.13)
            gd.ellipse([cx-Rc*2, cy-Rc*2, cx+Rc*2, cy+Rc*2], fill=(*CYAN, 110))
            glow = glow.filter(ImageFilter.GaussianBlur(S // 14))
            img = Image.alpha_composite(img, glow)
            d = ImageDraw.Draw(img)
            d.ellipse([cx-Rc, cy-Rc, cx+Rc, cy+Rc], fill=(*WHITE, 255))
            return img.resize((sz, sz), Image.LANCZOS)

        sizes = [256, 128, 64, 48, 32, 16]
        frames = [_render(s) for s in sizes]
        frames[0].save(ico, format="ICO", append_images=frames[1:],
                       sizes=[(s, s) for s in sizes])
        print(ok("  Icon generated"))
        return ico
    except Exception as e:
        print(warn(f"  Icon generation failed: {e}"))
        return None

def _create_shortcut():
    desktop = _get_desktop()
    desktop.mkdir(parents=True, exist_ok=True)

    script = BASE_DIR / "main.py"
    pythonw = PY_DIR / "pythonw.exe"
    target = str(pythonw if pythonw.exists() else PYTHON)

    ico = _build_icon()
    icon_str = f"{ico},0" if ico and ico.exists() else f"{target},0"

    if IS_WIN:
        lnk = desktop / "JARVIS.lnk"
        try:
            from win32com.client import Dispatch
            sh = Dispatch("WScript.Shell")
            sc = sh.CreateShortCut(str(lnk))
            sc.TargetPath       = target
            sc.Arguments        = f'"{script}"'
            sc.WorkingDirectory = str(BASE_DIR)
            sc.Description      = "J.A.R.V.I.S AI Assistant - Mark XLIX"
            sc.IconLocation     = icon_str
            sc.save()
            print(ok(f"  Shortcut created: {lnk}"))
            return lnk
        except Exception:
            pass

        # Fallback: wscript + VBScript (no console window)
        def q(s): return s.replace('"', '""')
        vbs = "\n".join([
            'On Error Resume Next',
            'Set ws = CreateObject("WScript.Shell")',
            f'Set sc = ws.CreateShortcut("{q(str(lnk))}")',
            f'sc.TargetPath = "{q(target)}"',
            f'sc.Arguments = Chr(34) & "{q(str(script))}" & Chr(34)',
            f'sc.WorkingDirectory = "{q(str(BASE_DIR))}"',
            'sc.Description = "J.A.R.V.I.S AI Assistant"',
            f'sc.IconLocation = "{q(icon_str)}"',
            'sc.Save',
        ])
        import tempfile
        fd, tmp = tempfile.mkstemp(suffix=".vbs")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(vbs)
            subprocess.run(["wscript.exe", "/nologo", tmp],
                           capture_output=True, timeout=10,
                           creationflags=getattr(subprocess, "DETACHED_PROCESS", 0)
                           | getattr(subprocess, "CREATE_NO_WINDOW", 0))
        finally:
            try: os.unlink(tmp)
            except Exception: pass

        if lnk.exists():
            print(ok(f"  Shortcut created: {lnk}"))
            return lnk
        else:
            print(err("  Shortcut creation failed"))
            return None

    else:
        # macOS / Linux
        desk = desktop / "JARVIS.desktop"
        desk.write_text(
            "[Desktop Entry]\nName=J.A.R.V.I.S\n"
            f'Exec="{PYTHON}" "{script}"\n'
            f"Path={BASE_DIR}\nType=Application\nTerminal=false\n"
            f"Icon={ico}\nCategories=Utility;\n"
        )
        desk.chmod(desk.stat().st_mode | 0o755)
        try:
            subprocess.run(["gio", "set", str(desk), "metadata::trusted", "true"],
                           capture_output=True, timeout=5)
        except Exception:
            pass
        print(ok(f"  Shortcut created: {desk}"))
        return desk

# -- Main ----------------------------------------------------------------------

def main():
    print(BANNER)

    steps = [
        ("Python version",   _python_ok),
        ("Dependencies",     _pip_install),
        ("Playwright",       _playwright_install),
        ("pywin32",          _pywin32_fix),
    ]

    for name, fn in steps:
        print(bold(f"\n[{name}]"))
        if not fn():
            print(err(f"\n  Failed at: {name}"))
            print(warn("  Fix the error above and run this installer again."))
            input("\n  Press Enter to exit...")
            return

    print(bold("\n[Desktop Shortcut]"))
    _create_shortcut()

    print(bold("\n" + "=" * 50))
    print(ok("  INSTALLATION COMPLETE"))
    print(hi(f"  Run:  python \"{BASE_DIR / 'main.py'}\""))
    print(hi("  Or double-click the JARVIS shortcut on your Desktop"))
    print(bold("=" * 50))

    input("\n  Press Enter to exit...")

if __name__ == "__main__":
    main()
